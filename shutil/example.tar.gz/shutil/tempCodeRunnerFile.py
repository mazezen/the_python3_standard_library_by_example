    print(' Accessed:', time.ctime(stat_info.st_atime))
    print(' Modified:', time.ctime(stat_info.st_mtime))